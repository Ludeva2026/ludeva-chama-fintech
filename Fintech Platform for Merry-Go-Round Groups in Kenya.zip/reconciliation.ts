import { getDb } from "./db";
import { eq, and, lte, gte } from "drizzle-orm";
import { members, contributions, disbursements, reconciliations } from "../drizzle/schema";

/**
 * Reconciliation and Disbursement Logic
 * Handles automated reconciliation, fee calculations, and payout scheduling
 */

const PLATFORM_FEE_PERCENTAGE = 5;

interface ReconciliationResult {
  memberId: number;
  totalContributions: number;
  totalDisbursements: number;
  platformFeeDeducted: number;
  netBalance: number;
  reconciliationDate: Date;
}

interface SlotPayoutSchedule {
  slotNumber: number;
  memberId: number;
  memberName: string;
  payoutAmount: number;
  payoutDate: Date;
  status: "pending" | "scheduled" | "completed";
}

/**
 * Calculate platform fee for a given amount
 */
export function calculatePlatformFee(amount: number): number {
  return (amount * PLATFORM_FEE_PERCENTAGE) / 100;
}

/**
 * Generate monthly reconciliation for a member
 */
export async function generateMonthlyReconciliation(
  memberId: number,
  month: number,
  year: number
): Promise<ReconciliationResult | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    // Get member
    const memberRecord = await db
      .select()
      .from(members)
      .where(eq(members.id, memberId))
      .limit(1);

    if (!memberRecord.length) return null;

    const member = memberRecord[0];

    // Calculate total contributions for the month
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);

    const monthlyContributions = await db
      .select()
      .from(contributions)
      .where(
        and(
          eq(contributions.memberId, memberId),
          gte(contributions.contributionDate, startDate),
          lte(contributions.contributionDate, endDate)
        )
      );

    const totalContributions = monthlyContributions.reduce(
      (sum, c) => sum + parseFloat(c.amount),
      0
    );

    // Calculate total disbursements for the month
    const monthlyDisbursements = await db
      .select()
      .from(disbursements)
      .where(
        and(
          eq(disbursements.memberId, memberId),
          gte(disbursements.createdAt, startDate),
          lte(disbursements.createdAt, endDate)
        )
      );

    const totalDisbursements = monthlyDisbursements.reduce(
      (sum, d) => sum + parseFloat(d.amount),
      0
    );

    const platformFeeDeducted = calculatePlatformFee(totalContributions);
    const netBalance = totalContributions - platformFeeDeducted - totalDisbursements;

    return {
      memberId,
      totalContributions,
      totalDisbursements,
      platformFeeDeducted,
      netBalance,
      reconciliationDate: new Date(),
    };
  } catch (error) {
    console.error("Error generating monthly reconciliation:", error);
    return null;
  }
}

/**
 * Generate year-end reconciliation for a member
 */
export async function generateYearEndReconciliation(
  memberId: number,
  year: number
): Promise<ReconciliationResult | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    // Get member
    const memberRecord = await db
      .select()
      .from(members)
      .where(eq(members.id, memberId))
      .limit(1);

    if (!memberRecord.length) return null;

    const member = memberRecord[0];

    // Calculate total contributions for the year
    const startDate = new Date(year, 0, 1);
    const endDate = new Date(year, 11, 31);

    const yearlyContributions = await db
      .select()
      .from(contributions)
      .where(
        and(
          eq(contributions.memberId, memberId),
          gte(contributions.contributionDate, startDate),
          lte(contributions.contributionDate, endDate)
        )
      );

    const totalContributions = yearlyContributions.reduce(
      (sum, c) => sum + parseFloat(c.amount),
      0
    );

    // Calculate total disbursements for the year
    const yearlyDisbursements = await db
      .select()
      .from(disbursements)
      .where(
        and(
          eq(disbursements.memberId, memberId),
          gte(disbursements.createdAt, startDate),
          lte(disbursements.createdAt, endDate)
        )
      );

    const totalDisbursements = yearlyDisbursements.reduce(
      (sum, d) => sum + parseFloat(d.amount),
      0
    );

    const platformFeeDeducted = calculatePlatformFee(totalContributions);
    const netBalance = totalContributions - platformFeeDeducted - totalDisbursements;

    return {
      memberId,
      totalContributions,
      totalDisbursements,
      platformFeeDeducted,
      netBalance,
      reconciliationDate: new Date(),
    };
  } catch (error) {
    console.error("Error generating year-end reconciliation:", error);
    return null;
  }
}

/**
 * Generate slot-based payout schedule
 * Creates a schedule for periodic payouts based on slot numbers
 */
export async function generateSlotBasedPayoutSchedule(
  groupId: number,
  payoutAmount: number,
  payoutFrequency: "weekly" | "bi-weekly" | "monthly" = "monthly"
): Promise<SlotPayoutSchedule[]> {
  const db = await getDb();
  if (!db) return [];

  try {
    // Get all members in the group
    const groupMembers = await db
      .select()
      .from(members)
      .where(eq(members.groupId, groupId));

    // Sort by slot number
    const sortedMembers = groupMembers.sort(
      (a, b) => (a.slotNumber || 0) - (b.slotNumber || 0)
    );

    const schedule: SlotPayoutSchedule[] = [];
    let currentDate = new Date();

    // Generate schedule for each member
    sortedMembers.forEach((member, index) => {
      // Calculate payout date based on frequency
      const payoutDate = new Date(currentDate);

      if (payoutFrequency === "weekly") {
        payoutDate.setDate(payoutDate.getDate() + index * 7);
      } else if (payoutFrequency === "bi-weekly") {
        payoutDate.setDate(payoutDate.getDate() + index * 14);
      } else {
        // monthly
        payoutDate.setMonth(payoutDate.getMonth() + index);
      }

      schedule.push({
        slotNumber: member.slotNumber || index + 1,
        memberId: member.id,
        memberName: member.memberName,
        payoutAmount,
        payoutDate,
        status: "pending",
      });
    });

    return schedule;
  } catch (error) {
    console.error("Error generating slot-based payout schedule:", error);
    return [];
  }
}

/**
 * Calculate year-end distribution
 * Distributes all group savings to members at year-end
 */
export async function calculateYearEndDistribution(
  groupId: number
): Promise<Array<{ memberId: number; memberName: string; distributionAmount: number }>> {
  const db = await getDb();
  if (!db) return [];

  try {
    // Get all members in the group
    const groupMembers = await db
      .select()
      .from(members)
      .where(eq(members.groupId, groupId));

    // Calculate total group contributions
    const allContributions = await db
      .select()
      .from(contributions)
      .where(eq(contributions.groupId, groupId));

    const totalContributions = allContributions.reduce(
      (sum, c) => sum + parseFloat(c.amount),
      0
    );

    // Calculate total disbursements already made
    const allDisbursements = await db
      .select()
      .from(disbursements)
      .where(eq(disbursements.groupId, groupId));

    const totalDisbursements = allDisbursements.reduce(
      (sum, d) => sum + parseFloat(d.amount),
      0
    );

    // Calculate platform fee
    const platformFee = calculatePlatformFee(totalContributions);

    // Calculate available balance for distribution
    const availableBalance = totalContributions - platformFee - totalDisbursements;

    // Distribute equally among members
    const distributionPerMember = availableBalance / groupMembers.length;

    return groupMembers.map((member) => ({
      memberId: member.id,
      memberName: member.memberName,
      distributionAmount: distributionPerMember,
    }));
  } catch (error) {
    console.error("Error calculating year-end distribution:", error);
    return [];
  }
}

/**
 * Process automated reconciliation for all members in a group
 */
export async function processGroupReconciliation(
  groupId: number,
  reconciliationPeriod: string
): Promise<ReconciliationResult[]> {
  const db = await getDb();
  if (!db) return [];

  try {
    // Get all members in the group
    const groupMembers = await db
      .select()
      .from(members)
      .where(eq(members.groupId, groupId));

    const results: ReconciliationResult[] = [];

    // Generate reconciliation for each member
    for (const member of groupMembers) {
      const totalContributions = parseFloat(member.totalContributed);
      const totalDisbursements = parseFloat(member.totalDisbursed);
      const platformFeeDeducted = calculatePlatformFee(totalContributions);
      const netBalance = totalContributions - platformFeeDeducted - totalDisbursements;

      results.push({
        memberId: member.id,
        totalContributions,
        totalDisbursements,
        platformFeeDeducted,
        netBalance,
        reconciliationDate: new Date(),
      });
    }

    return results;
  } catch (error) {
    console.error("Error processing group reconciliation:", error);
    return [];
  }
}

/**
 * Validate member eligibility for payout
 */
export async function validatePayoutEligibility(
  memberId: number
): Promise<{ eligible: boolean; reason?: string }> {
  const db = await getDb();
  if (!db) return { eligible: false, reason: "Database not available" };

  try {
    const member = await db
      .select()
      .from(members)
      .where(eq(members.id, memberId))
      .limit(1);

    if (!member.length) {
      return { eligible: false, reason: "Member not found" };
    }

    const memberRecord = member[0];

    // Check if member has generated Ludeva number
    if (!memberRecord.ludevaNumber) {
      return { eligible: false, reason: "Ludeva number not generated" };
    }

    // Check if member has made at least one contribution
    const memberContributions = await db
      .select()
      .from(contributions)
      .where(eq(contributions.memberId, memberId))
      .limit(1);

    if (!memberContributions.length) {
      return { eligible: false, reason: "No contributions recorded" };
    }

    return { eligible: true };
  } catch (error) {
    console.error("Error validating payout eligibility:", error);
    return { eligible: false, reason: "Validation error" };
  }
}
