import { describe, it, expect, beforeEach } from "vitest";
import { calculatePlatformFee } from "./reconciliation";
import { validatePhoneNumber, formatPhoneNumber } from "./mpesa";

describe("Reconciliation Module", () => {
  describe("calculatePlatformFee", () => {
    it("should calculate 5% fee correctly", () => {
      const amount = 10000;
      const fee = calculatePlatformFee(amount);
      expect(fee).toBe(500);
    });

    it("should handle decimal amounts", () => {
      const amount = 10000.50;
      const fee = calculatePlatformFee(amount);
      expect(fee).toBeCloseTo(500.025, 2);
    });

    it("should return 0 for zero amount", () => {
      const fee = calculatePlatformFee(0);
      expect(fee).toBe(0);
    });

    it("should handle large amounts", () => {
      const amount = 1000000;
      const fee = calculatePlatformFee(amount);
      expect(fee).toBe(50000);
    });
  });
});

describe("M-Pesa Integration", () => {
  describe("validatePhoneNumber", () => {
    it("should validate Kenyan phone numbers starting with 254", () => {
      expect(validatePhoneNumber("254712345678")).toBe(true);
    });

    it("should validate Kenyan phone numbers starting with +254", () => {
      expect(validatePhoneNumber("+254712345678")).toBe(true);
    });

    it("should validate Kenyan phone numbers starting with 0", () => {
      expect(validatePhoneNumber("0712345678")).toBe(true);
    });

    it("should reject invalid phone numbers", () => {
      expect(validatePhoneNumber("1234567890")).toBe(false);
    });

    it("should reject phone numbers with invalid length", () => {
      expect(validatePhoneNumber("25471234567")).toBe(false);
    });

    it("should handle phone numbers with spaces", () => {
      expect(validatePhoneNumber("0712 345 678")).toBe(true);
    });
  });

  describe("formatPhoneNumber", () => {
    it("should format phone number starting with 0", () => {
      const formatted = formatPhoneNumber("0712345678");
      expect(formatted).toBe("254712345678");
    });

    it("should format phone number starting with 254", () => {
      const formatted = formatPhoneNumber("254712345678");
      expect(formatted).toBe("254712345678");
    });

    it("should format phone number starting with +254", () => {
      const formatted = formatPhoneNumber("+254712345678");
      expect(formatted).toBe("254712345678");
    });

    it("should remove spaces from phone number", () => {
      const formatted = formatPhoneNumber("0712 345 678");
      expect(formatted).toBe("254712345678");
    });

    it("should remove dashes from phone number", () => {
      const formatted = formatPhoneNumber("0712-345-678");
      expect(formatted).toBe("254712345678");
    });
  });
});

describe("Business Logic", () => {
  describe("Contribution Tracking", () => {
    it("should calculate total contributions correctly", () => {
      const contributions = [
        { amount: 1000 },
        { amount: 2000 },
        { amount: 1500 },
      ];
      const total = contributions.reduce((sum, c) => sum + c.amount, 0);
      expect(total).toBe(4500);
    });

    it("should calculate net balance after fee deduction", () => {
      const totalContributed = 10000;
      const totalDisbursed = 3000;
      const platformFee = calculatePlatformFee(totalContributed);
      const netBalance = totalContributed - platformFee - totalDisbursed;
      expect(netBalance).toBe(6500); // 10000 - 500 - 3000
    });
  });

  describe("Group Management", () => {
    it("should enforce exactly 10 members", () => {
      const maxMembers = 10;
      const members = Array(10).fill({ name: "Member" });
      expect(members.length).toBe(maxMembers);
    });

    it("should validate Ludeva number generation cost", () => {
      const ludevaNumberCost = 100;
      const memberCount = 10;
      const totalCost = ludevaNumberCost * memberCount;
      expect(totalCost).toBe(1000);
    });
  });

  describe("Disbursement Logic", () => {
    it("should calculate slot-based payout", () => {
      const totalBalance = 10000;
      const memberCount = 10;
      const payoutPerMember = totalBalance / memberCount;
      expect(payoutPerMember).toBe(1000);
    });

    it("should handle year-end distribution", () => {
      const totalContributions = 50000;
      const platformFee = calculatePlatformFee(totalContributions);
      const totalDisbursements = 10000;
      const availableBalance = totalContributions - platformFee - totalDisbursements;
      const memberCount = 10;
      const distributionPerMember = availableBalance / memberCount;
      expect(distributionPerMember).toBe(3750); // (50000 - 2500 - 10000) / 10
    });
  });

  describe("Reconciliation", () => {
    it("should generate accurate reconciliation statement", () => {
      const totalContributions = 20000;
      const totalDisbursements = 5000;
      const platformFeeDeducted = calculatePlatformFee(totalContributions);
      const netBalance = totalContributions - platformFeeDeducted - totalDisbursements;

      expect(platformFeeDeducted).toBe(1000);
      expect(netBalance).toBe(14000);
    });

    it("should handle multiple reconciliation periods", () => {
      const periods = [
        { month: 1, contributions: 5000 },
        { month: 2, contributions: 6000 },
        { month: 3, contributions: 7000 },
      ];

      const totalContributions = periods.reduce((sum, p) => sum + p.contributions, 0);
      const totalFee = calculatePlatformFee(totalContributions);

      expect(totalContributions).toBe(18000);
      expect(totalFee).toBe(900);
    });
  });

  describe("Data Validation", () => {
    it("should validate positive amounts", () => {
      const amount = 1000;
      expect(amount > 0).toBe(true);
    });

    it("should validate group code format", () => {
      const groupCode = "LDV-ABC123-XYZ789";
      const pattern = /^LDV-[A-Z0-9]+-[A-Z0-9]+$/;
      expect(pattern.test(groupCode)).toBe(true);
    });

    it("should validate Ludeva number format", () => {
      const ludevaNumber = "LUD-ABC123-XYZ789";
      const pattern = /^LUD-[A-Z0-9]+-[A-Z0-9]+$/;
      expect(pattern.test(ludevaNumber)).toBe(true);
    });

    it("should validate slot numbers 1-10", () => {
      for (let slot = 1; slot <= 10; slot++) {
        expect(slot >= 1 && slot <= 10).toBe(true);
      }
    });
  });
});
