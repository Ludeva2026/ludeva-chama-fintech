CREATE TABLE `contributions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`memberId` int NOT NULL,
	`groupId` int NOT NULL,
	`amount` decimal(12,2) NOT NULL,
	`contributionDate` timestamp NOT NULL DEFAULT (now()),
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'completed',
	`transactionRef` varchar(100),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `contributions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `disbursements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`memberId` int NOT NULL,
	`groupId` int NOT NULL,
	`amount` decimal(12,2) NOT NULL,
	`disbursementType` enum('slot-based','year-end') NOT NULL,
	`slotNumber` int,
	`status` enum('pending','processed','completed','failed') NOT NULL DEFAULT 'pending',
	`disbursementDate` timestamp,
	`transactionRef` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `disbursements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `groups` (
	`id` int AUTO_INCREMENT NOT NULL,
	`groupName` varchar(255) NOT NULL,
	`groupCode` varchar(50) NOT NULL,
	`teamLeadId` int,
	`disbursementMandate` enum('slot-based','year-end') NOT NULL,
	`totalMembers` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT false,
	`totalFundBalance` decimal(12,2) NOT NULL DEFAULT '0.00',
	`platformFeePercentage` decimal(5,2) NOT NULL DEFAULT '5.00',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `groups_id` PRIMARY KEY(`id`),
	CONSTRAINT `groups_groupCode_unique` UNIQUE(`groupCode`)
);
--> statement-breakpoint
CREATE TABLE `ludevaNumbers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`memberId` int NOT NULL,
	`groupId` int NOT NULL,
	`ludevaNumber` varchar(50) NOT NULL,
	`cost` decimal(12,2) NOT NULL DEFAULT '100.00',
	`paymentStatus` enum('pending','paid','failed') NOT NULL DEFAULT 'pending',
	`paymentDate` timestamp,
	`transactionRef` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ludevaNumbers_id` PRIMARY KEY(`id`),
	CONSTRAINT `ludevaNumbers_ludevaNumber_unique` UNIQUE(`ludevaNumber`)
);
--> statement-breakpoint
CREATE TABLE `members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`groupId` int NOT NULL,
	`memberName` varchar(255) NOT NULL,
	`memberPhone` varchar(20),
	`memberEmail` varchar(320),
	`slotNumber` int,
	`ludevaNumber` varchar(50),
	`isTeamLead` boolean NOT NULL DEFAULT false,
	`totalContributed` decimal(12,2) NOT NULL DEFAULT '0.00',
	`totalDisbursed` decimal(12,2) NOT NULL DEFAULT '0.00',
	`platformFeeDeducted` decimal(12,2) NOT NULL DEFAULT '0.00',
	`outstandingBalance` decimal(12,2) NOT NULL DEFAULT '0.00',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `members_id` PRIMARY KEY(`id`),
	CONSTRAINT `members_ludevaNumber_unique` UNIQUE(`ludevaNumber`)
);
--> statement-breakpoint
CREATE TABLE `reconciliations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`memberId` int NOT NULL,
	`groupId` int NOT NULL,
	`reconciliationPeriod` varchar(50) NOT NULL,
	`totalContributions` decimal(12,2) NOT NULL DEFAULT '0.00',
	`totalDisbursements` decimal(12,2) NOT NULL DEFAULT '0.00',
	`platformFeeDeducted` decimal(12,2) NOT NULL DEFAULT '0.00',
	`netBalance` decimal(12,2) NOT NULL DEFAULT '0.00',
	`statementDate` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reconciliations_id` PRIMARY KEY(`id`)
);
