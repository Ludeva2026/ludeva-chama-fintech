import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, date } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Ludeva - Team Groups Table
 * Represents a merry-go-round group with fixed 10-member size
 */
export const groups = mysqlTable("groups", {
  id: int("id").autoincrement().primaryKey(),
  groupName: varchar("groupName", { length: 255 }).notNull(),
  groupCode: varchar("groupCode", { length: 50 }).notNull().unique(),
  teamLeadId: int("teamLeadId"),
  disbursementMandate: mysqlEnum("disbursementMandate", ["slot-based", "year-end"]).notNull(),
  totalMembers: int("totalMembers").default(0).notNull(),
  isActive: boolean("isActive").default(false).notNull(),
  totalFundBalance: decimal("totalFundBalance", { precision: 12, scale: 2 }).default("0.00").notNull(),
  platformFeePercentage: decimal("platformFeePercentage", { precision: 5, scale: 2 }).default("5.00").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Group = typeof groups.$inferSelect;
export type InsertGroup = typeof groups.$inferInsert;

/**
 * Ludeva - Team Members Table
 * Represents individual members within a group
 */
export const members = mysqlTable("members", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  groupId: int("groupId").notNull(),
  memberName: varchar("memberName", { length: 255 }).notNull(),
  memberPhone: varchar("memberPhone", { length: 20 }),
  memberEmail: varchar("memberEmail", { length: 320 }),
  slotNumber: int("slotNumber"),
  ludevaNumber: varchar("ludevaNumber", { length: 50 }).unique(),
  isTeamLead: boolean("isTeamLead").default(false).notNull(),
  totalContributed: decimal("totalContributed", { precision: 12, scale: 2 }).default("0.00").notNull(),
  totalDisbursed: decimal("totalDisbursed", { precision: 12, scale: 2 }).default("0.00").notNull(),
  platformFeeDeducted: decimal("platformFeeDeducted", { precision: 12, scale: 2 }).default("0.00").notNull(),
  outstandingBalance: decimal("outstandingBalance", { precision: 12, scale: 2 }).default("0.00").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Member = typeof members.$inferSelect;
export type InsertMember = typeof members.$inferInsert;

/**
 * Contributions Table
 * Tracks all member contributions with timestamps for transparency
 */
export const contributions = mysqlTable("contributions", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("memberId").notNull(),
  groupId: int("groupId").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  contributionDate: timestamp("contributionDate").defaultNow().notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("completed").notNull(),
  transactionRef: varchar("transactionRef", { length: 100 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Contribution = typeof contributions.$inferSelect;
export type InsertContribution = typeof contributions.$inferInsert;

/**
 * Disbursements Table
 * Tracks all payouts to members (slot-based or year-end)
 */
export const disbursements = mysqlTable("disbursements", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("memberId").notNull(),
  groupId: int("groupId").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  disbursementType: mysqlEnum("disbursementType", ["slot-based", "year-end"]).notNull(),
  slotNumber: int("slotNumber"),
  status: mysqlEnum("status", ["pending", "processed", "completed", "failed"]).default("pending").notNull(),
  disbursementDate: timestamp("disbursementDate"),
  transactionRef: varchar("transactionRef", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Disbursement = typeof disbursements.$inferSelect;
export type InsertDisbursement = typeof disbursements.$inferInsert;

/**
 * Reconciliation Table
 * Stores monthly/annual account statements for each member
 */
export const reconciliations = mysqlTable("reconciliations", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("memberId").notNull(),
  groupId: int("groupId").notNull(),
  reconciliationPeriod: varchar("reconciliationPeriod", { length: 50 }).notNull(),
  totalContributions: decimal("totalContributions", { precision: 12, scale: 2 }).default("0.00").notNull(),
  totalDisbursements: decimal("totalDisbursements", { precision: 12, scale: 2 }).default("0.00").notNull(),
  platformFeeDeducted: decimal("platformFeeDeducted", { precision: 12, scale: 2 }).default("0.00").notNull(),
  netBalance: decimal("netBalance", { precision: 12, scale: 2 }).default("0.00").notNull(),
  statementDate: timestamp("statementDate").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Reconciliation = typeof reconciliations.$inferSelect;
export type InsertReconciliation = typeof reconciliations.$inferInsert;

/**
 * Ludeva Numbers Table
 * Tracks Ludeva number generation (Ksh 100 per person)
 */
export const ludevaNumbers = mysqlTable("ludevaNumbers", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("memberId").notNull(),
  groupId: int("groupId").notNull(),
  ludevaNumber: varchar("ludevaNumber", { length: 50 }).notNull().unique(),
  cost: decimal("cost", { precision: 12, scale: 2 }).default("100.00").notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "failed"]).default("pending").notNull(),
  paymentDate: timestamp("paymentDate"),
  transactionRef: varchar("transactionRef", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LudevaNumber = typeof ludevaNumbers.$inferSelect;
export type InsertLudevaNumber = typeof ludevaNumbers.$inferInsert;

// Relations
export const groupsRelations = relations(groups, ({ many }) => ({
  members: many(members),
  contributions: many(contributions),
  disbursements: many(disbursements),
  reconciliations: many(reconciliations),
}));

export const membersRelations = relations(members, ({ one, many }) => ({
  group: one(groups, {
    fields: [members.groupId],
    references: [groups.id],
  }),
  contributions: many(contributions),
  disbursements: many(disbursements),
  reconciliations: many(reconciliations),
}));

export const contributionsRelations = relations(contributions, ({ one }) => ({
  member: one(members, {
    fields: [contributions.memberId],
    references: [members.id],
  }),
  group: one(groups, {
    fields: [contributions.groupId],
    references: [groups.id],
  }),
}));

export const disbursementsRelations = relations(disbursements, ({ one }) => ({
  member: one(members, {
    fields: [disbursements.memberId],
    references: [members.id],
  }),
  group: one(groups, {
    fields: [disbursements.groupId],
    references: [groups.id],
  }),
}));

export const reconciliationsRelations = relations(reconciliations, ({ one }) => ({
  member: one(members, {
    fields: [reconciliations.memberId],
    references: [members.id],
  }),
  group: one(groups, {
    fields: [reconciliations.groupId],
    references: [groups.id],
  }),
}));

export const ludevaNumbersRelations = relations(ludevaNumbers, ({ one }) => ({
  group: one(groups, {
    fields: [ludevaNumbers.groupId],
    references: [groups.id],
  }),
}));

