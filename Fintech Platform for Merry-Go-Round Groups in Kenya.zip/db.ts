import { eq, and, sum, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, groups, members, contributions, disbursements, reconciliations, ludevaNumbers } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ GROUP MANAGEMENT ============

export async function createGroup(groupData: {
  groupName: string;
  groupCode: string;
  disbursementMandate: "slot-based" | "year-end";
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(groups).values({
    groupName: groupData.groupName,
    groupCode: groupData.groupCode,
    disbursementMandate: groupData.disbursementMandate,
    totalMembers: 0,
    isActive: false,
  });

  return result;
}

export async function getGroupById(groupId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(groups).where(eq(groups.id, groupId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getGroupByCode(groupCode: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(groups).where(eq(groups.groupCode, groupCode)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function updateGroupStatus(groupId: number, isActive: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(groups).set({ isActive }).where(eq(groups.id, groupId));
}

export async function updateGroupTeamLead(groupId: number, teamLeadId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(groups).set({ teamLeadId }).where(eq(groups.id, groupId));
}

export async function updateGroupFundBalance(groupId: number, amount: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(groups).set({ totalFundBalance: amount }).where(eq(groups.id, groupId));
}

// ============ MEMBER MANAGEMENT ============

export async function addMember(memberData: {
  userId: number;
  groupId: number;
  memberName: string;
  memberPhone?: string;
  memberEmail?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(members).values({
    userId: memberData.userId,
    groupId: memberData.groupId,
    memberName: memberData.memberName,
    memberPhone: memberData.memberPhone,
    memberEmail: memberData.memberEmail,
    isTeamLead: false,
  });

  return result;
}

export async function getMembersByGroupId(groupId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(members).where(eq(members.groupId, groupId));
}

export async function getMemberById(memberId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(members).where(eq(members.id, memberId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function updateMemberSlot(memberId: number, slotNumber: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(members).set({ slotNumber }).where(eq(members.id, memberId));
}

export async function updateMemberAsTeamLead(memberId: number, groupId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Remove team lead from all members in the group
  await db.update(members).set({ isTeamLead: false }).where(eq(members.groupId, groupId));

  // Set the new team lead
  await db.update(members).set({ isTeamLead: true }).where(eq(members.id, memberId));
}

export async function updateMemberLudevaNumber(memberId: number, ludevaNumber: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(members).set({ ludevaNumber }).where(eq(members.id, memberId));
}

export async function updateMemberBalance(memberId: number, totalContributed: string, totalDisbursed: string, platformFeeDeducted: string, outstandingBalance: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(members).set({
    totalContributed,
    totalDisbursed,
    platformFeeDeducted,
    outstandingBalance,
  }).where(eq(members.id, memberId));
}

// ============ CONTRIBUTION TRACKING ============

export async function recordContribution(contributionData: {
  memberId: number;
  groupId: number;
  amount: string;
  transactionRef?: string;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(contributions).values({
    memberId: contributionData.memberId,
    groupId: contributionData.groupId,
    amount: contributionData.amount,
    transactionRef: contributionData.transactionRef,
    notes: contributionData.notes,
    status: "completed",
  });

  return result;
}

export async function getContributionsByGroupId(groupId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(contributions).where(eq(contributions.groupId, groupId)).orderBy(desc(contributions.contributionDate));
}

export async function getContributionsByMemberId(memberId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(contributions).where(eq(contributions.memberId, memberId)).orderBy(desc(contributions.contributionDate));
}

export async function getTotalContributionsByMember(memberId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select({ total: sum(contributions.amount) }).from(contributions).where(eq(contributions.memberId, memberId));
  return result[0]?.total || "0.00";
}

// ============ DISBURSEMENT MANAGEMENT ============

export async function createDisbursement(disbursementData: {
  memberId: number;
  groupId: number;
  amount: string;
  disbursementType: "slot-based" | "year-end";
  slotNumber?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(disbursements).values({
    memberId: disbursementData.memberId,
    groupId: disbursementData.groupId,
    amount: disbursementData.amount,
    disbursementType: disbursementData.disbursementType,
    slotNumber: disbursementData.slotNumber,
    status: "pending",
  });

  return result;
}

export async function getDisbursementsByGroupId(groupId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(disbursements).where(eq(disbursements.groupId, groupId)).orderBy(desc(disbursements.createdAt));
}

export async function getDisbursementsByMemberId(memberId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(disbursements).where(eq(disbursements.memberId, memberId)).orderBy(desc(disbursements.createdAt));
}

export async function updateDisbursementStatus(disbursementId: number, status: "pending" | "processed" | "completed" | "failed") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(disbursements).set({ status, disbursementDate: new Date() }).where(eq(disbursements.id, disbursementId));
}

// ============ LUDEVA NUMBER GENERATION ============

export async function generateLudevaNumber(ludevaNumberData: {
  memberId: number;
  groupId: number;
  ludevaNumber: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(ludevaNumbers).values({
    memberId: ludevaNumberData.memberId,
    groupId: ludevaNumberData.groupId,
    ludevaNumber: ludevaNumberData.ludevaNumber,
    cost: "100.00",
    paymentStatus: "pending",
  });

  return result;
}

export async function updateLudevaNumberPaymentStatus(ludevaNumberId: number, paymentStatus: "pending" | "paid" | "failed", transactionRef?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(ludevaNumbers).set({ paymentStatus, transactionRef, paymentDate: new Date() }).where(eq(ludevaNumbers.id, ludevaNumberId));
}

export async function getLudevaNumberByNumber(ludevaNumber: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(ludevaNumbers).where(eq(ludevaNumbers.ludevaNumber, ludevaNumber)).limit(1);
  return result.length > 0 ? result[0] : null;
}

// ============ RECONCILIATION ============

export async function createReconciliation(reconciliationData: {
  memberId: number;
  groupId: number;
  reconciliationPeriod: string;
  totalContributions: string;
  totalDisbursements: string;
  platformFeeDeducted: string;
  netBalance: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(reconciliations).values({
    memberId: reconciliationData.memberId,
    groupId: reconciliationData.groupId,
    reconciliationPeriod: reconciliationData.reconciliationPeriod,
    totalContributions: reconciliationData.totalContributions,
    totalDisbursements: reconciliationData.totalDisbursements,
    platformFeeDeducted: reconciliationData.platformFeeDeducted,
    netBalance: reconciliationData.netBalance,
  });

  return result;
}

export async function getReconciliationsByMemberId(memberId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(reconciliations).where(eq(reconciliations.memberId, memberId)).orderBy(desc(reconciliations.statementDate));
}

export async function getReconciliationsByGroupId(groupId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(reconciliations).where(eq(reconciliations.groupId, groupId)).orderBy(desc(reconciliations.statementDate));
}
