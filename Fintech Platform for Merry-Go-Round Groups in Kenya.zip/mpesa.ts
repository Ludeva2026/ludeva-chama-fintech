import axios from "axios";

/**
 * M-Pesa Integration Module
 * Handles payment processing for Ludeva - Team platform
 * Supports Ludeva number generation, contributions, and disbursements
 */

interface MpesaConfig {
  consumerKey: string;
  consumerSecret: string;
  businessShortCode: string;
  passkey: string;
  baseUrl: string;
  callbackUrl: string;
}

interface StkPushRequest {
  phoneNumber: string;
  amount: number;
  accountReference: string;
  transactionDescription: string;
  metadata?: Record<string, unknown>;
}

interface StkPushResponse {
  ResponseCode: string;
  ResponseDescription: string;
  MerchantRequestID: string;
  CheckoutRequestID: string;
}

interface PaymentCallback {
  Body: {
    stkCallback: {
      MerchantRequestID: string;
      CheckoutRequestID: string;
      ResultCode: number;
      ResultDesc: string;
      CallbackMetadata?: {
        Item: Array<{
          Name: string;
          Value: unknown;
        }>;
      };
    };
  };
}

let mpesaConfig: MpesaConfig | null = null;

/**
 * Initialize M-Pesa configuration
 * In production, these would come from environment variables
 */
export function initializeMpesa(config: MpesaConfig): void {
  mpesaConfig = config;
}

/**
 * Get M-Pesa access token
 */
async function getAccessToken(): Promise<string> {
  if (!mpesaConfig) {
    throw new Error("M-Pesa not configured");
  }

  try {
    const auth = Buffer.from(
      `${mpesaConfig.consumerKey}:${mpesaConfig.consumerSecret}`
    ).toString("base64");

    const response = await axios.get(
      `${mpesaConfig.baseUrl}/oauth/v1/generate?grant_type=client_credentials`,
      {
        headers: {
          Authorization: `Basic ${auth}`,
        },
      }
    );

    return response.data.access_token;
  } catch (error) {
    console.error("Failed to get M-Pesa access token:", error);
    throw error;
  }
}

/**
 * Generate STK push for payment
 * Initiates M-Pesa payment prompt on user's phone
 */
export async function initiatePayment(request: StkPushRequest): Promise<StkPushResponse> {
  if (!mpesaConfig) {
    throw new Error("M-Pesa not configured");
  }

  try {
    const accessToken = await getAccessToken();
    const timestamp = new Date().toISOString().replace(/[^0-9]/g, "").slice(0, -3);

    const password = Buffer.from(
      `${mpesaConfig.businessShortCode}${mpesaConfig.passkey}${timestamp}`
    ).toString("base64");

    const payload = {
      BusinessShortCode: mpesaConfig.businessShortCode,
      Password: password,
      Timestamp: timestamp,
      TransactionType: "CustomerPayBillOnline",
      Amount: Math.round(request.amount),
      PartyA: request.phoneNumber.replace(/\D/g, ""),
      PartyB: mpesaConfig.businessShortCode,
      PhoneNumber: request.phoneNumber.replace(/\D/g, ""),
      CallBackURL: mpesaConfig.callbackUrl,
      AccountReference: request.accountReference,
      TransactionDesc: request.transactionDescription,
    };

    const response = await axios.post(
      `${mpesaConfig.baseUrl}/mpesa/stkpush/v1/processrequest`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error("Failed to initiate M-Pesa payment:", error);
    throw error;
  }
}

/**
 * Query payment status
 */
export async function queryPaymentStatus(
  checkoutRequestId: string
): Promise<Record<string, unknown>> {
  if (!mpesaConfig) {
    throw new Error("M-Pesa not configured");
  }

  try {
    const accessToken = await getAccessToken();
    const timestamp = new Date().toISOString().replace(/[^0-9]/g, "").slice(0, -3);

    const password = Buffer.from(
      `${mpesaConfig.businessShortCode}${mpesaConfig.passkey}${timestamp}`
    ).toString("base64");

    const payload = {
      BusinessShortCode: mpesaConfig.businessShortCode,
      Password: password,
      Timestamp: timestamp,
      CheckoutRequestID: checkoutRequestId,
    };

    const response = await axios.post(
      `${mpesaConfig.baseUrl}/mpesa/stkpushquery/v1/query`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error("Failed to query M-Pesa payment status:", error);
    throw error;
  }
}

/**
 * Process payment callback from M-Pesa
 */
export function processPaymentCallback(callback: PaymentCallback): {
  success: boolean;
  transactionRef?: string;
  amount?: number;
  phoneNumber?: string;
} {
  const stkCallback = callback.Body.stkCallback;

  if (stkCallback.ResultCode !== 0) {
    return {
      success: false,
    };
  }

  // Extract callback metadata
  const metadata = stkCallback.CallbackMetadata?.Item || [];
  const transactionRef = metadata.find((item) => item.Name === "MpesaReceiptNumber")
    ?.Value as string;
  const amount = metadata.find((item) => item.Name === "Amount")?.Value as number;
  const phoneNumber = metadata.find((item) => item.Name === "PhoneNumber")
    ?.Value as string;

  return {
    success: true,
    transactionRef,
    amount,
    phoneNumber,
  };
}

/**
 * Initiate B2C payment (disbursement to member)
 */
export async function initiateDisbursement(
  phoneNumber: string,
  amount: number,
  reference: string,
  description: string
): Promise<Record<string, unknown>> {
  if (!mpesaConfig) {
    throw new Error("M-Pesa not configured");
  }

  try {
    const accessToken = await getAccessToken();

    const payload = {
      OriginatorConversationID: `${reference}-${Date.now()}`,
      InitiatorName: "Ludeva",
      SecurityCredential: mpesaConfig.businessShortCode, // In production, this should be encrypted
      CommandID: "BusinessPayment",
      Amount: Math.round(amount),
      PartyA: mpesaConfig.businessShortCode,
      PartyB: phoneNumber.replace(/\D/g, ""),
      Remarks: description,
      QueueTimeOutURL: mpesaConfig.callbackUrl,
      ResultURL: mpesaConfig.callbackUrl,
      Occasion: reference,
    };

    const response = await axios.post(
      `${mpesaConfig.baseUrl}/mpesa/b2c/v1/paymentrequest`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error("Failed to initiate M-Pesa disbursement:", error);
    throw error;
  }
}

/**
 * Validate phone number format
 */
export function validatePhoneNumber(phoneNumber: string): boolean {
  // Kenyan phone number format: 254XXXXXXXXX or 07XXXXXXXX
  const pattern = /^(?:254|\+254|0)?[17]\d{8}$/;
  return pattern.test(phoneNumber.replace(/\s/g, ""));
}

/**
 * Format phone number to M-Pesa standard (254XXXXXXXXX)
 */
export function formatPhoneNumber(phoneNumber: string): string {
  let formatted = phoneNumber.replace(/\D/g, "");

  // Handle different input formats
  if (formatted.startsWith("0")) {
    formatted = "254" + formatted.slice(1);
  } else if (!formatted.startsWith("254")) {
    formatted = "254" + formatted;
  }

  return formatted;
}
