import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

// Helper function to generate unique group code
function generateGroupCode(): string {
  return `LDV-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
}

// Helper function to generate Ludeva number
function generateLudevaNumber(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `LUD-${timestamp}-${random}`;
}

// Helper function to calculate platform fee
function calculatePlatformFee(amount: number, feePercentage: number = 5): number {
  return (amount * feePercentage) / 100;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ GROUP MANAGEMENT ============
  groups: router({
    create: protectedProcedure
      .input(z.object({
        groupName: z.string().min(1, "Group name is required"),
        disbursementMandate: z.enum(["slot-based", "year-end"]),
      }))
      .mutation(async ({ input }) => {
        const groupCode = generateGroupCode();
        await db.createGroup({
          groupName: input.groupName,
          groupCode,
          disbursementMandate: input.disbursementMandate,
        });
        return { groupCode, success: true };
      }),

    getByCode: publicProcedure
      .input(z.object({ groupCode: z.string() }))
      .query(async ({ input }) => {
        const group = await db.getGroupByCode(input.groupCode);
        if (!group) throw new TRPCError({ code: "NOT_FOUND", message: "Group not found" });
        return group;
      }),

    getById: publicProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        const group = await db.getGroupById(input.groupId);
        if (!group) throw new TRPCError({ code: "NOT_FOUND", message: "Group not found" });
        return group;
      }),

    updateTeamLead: protectedProcedure
      .input(z.object({ groupId: z.number(), teamLeadId: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateGroupTeamLead(input.groupId, input.teamLeadId);
        await db.updateMemberAsTeamLead(input.teamLeadId, input.groupId);
        return { success: true };
      }),

    activate: protectedProcedure
      .input(z.object({ groupId: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateGroupStatus(input.groupId, true);
        return { success: true };
      }),
  }),

  // ============ MEMBER MANAGEMENT ============
  members: router({
    add: protectedProcedure
      .input(z.object({
        groupId: z.number(),
        memberName: z.string().min(1, "Member name is required"),
        memberPhone: z.string().optional(),
        memberEmail: z.string().email().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });

        await db.addMember({
          userId: ctx.user.id,
          groupId: input.groupId,
          memberName: input.memberName,
          memberPhone: input.memberPhone,
          memberEmail: input.memberEmail,
        });

        return { success: true };
      }),

    getByGroup: publicProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return await db.getMembersByGroupId(input.groupId);
      }),

    getById: publicProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input }) => {
        const member = await db.getMemberById(input.memberId);
        if (!member) throw new TRPCError({ code: "NOT_FOUND", message: "Member not found" });
        return member;
      }),

    assignSlot: protectedProcedure
      .input(z.object({ memberId: z.number(), slotNumber: z.number().min(1).max(10) }))
      .mutation(async ({ input }) => {
        await db.updateMemberSlot(input.memberId, input.slotNumber);
        return { success: true };
      }),

    setAsTeamLead: protectedProcedure
      .input(z.object({ memberId: z.number(), groupId: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateMemberAsTeamLead(input.memberId, input.groupId);
        return { success: true };
      }),
  }),

  // ============ LUDEVA NUMBER GENERATION ============
  ludevaNumbers: router({
    generate: protectedProcedure
      .input(z.object({ memberId: z.number(), groupId: z.number() }))
      .mutation(async ({ input }) => {
        const ludevaNumber = generateLudevaNumber();
        await db.generateLudevaNumber({
          memberId: input.memberId,
          groupId: input.groupId,
          ludevaNumber,
        });

        await db.updateMemberLudevaNumber(input.memberId, ludevaNumber);

        return { ludevaNumber, cost: 100, success: true };
      }),

    markAsPaid: protectedProcedure
      .input(z.object({ ludevaNumberId: z.number(), transactionRef: z.string().optional() }))
      .mutation(async ({ input }) => {
        await db.updateLudevaNumberPaymentStatus(input.ludevaNumberId, "paid", input.transactionRef);
        return { success: true };
      }),

    getByNumber: publicProcedure
      .input(z.object({ ludevaNumber: z.string() }))
      .query(async ({ input }) => {
        const ludevaNumber = await db.getLudevaNumberByNumber(input.ludevaNumber);
        if (!ludevaNumber) throw new TRPCError({ code: "NOT_FOUND", message: "Ludeva number not found" });
        return ludevaNumber;
      }),
  }),

  // ============ CONTRIBUTIONS ============
  contributions: router({
    record: protectedProcedure
      .input(z.object({
        memberId: z.number(),
        groupId: z.number(),
        amount: z.string().regex(/^\d+(\.\d{1,2})?$/),
        transactionRef: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.recordContribution({
          memberId: input.memberId,
          groupId: input.groupId,
          amount: input.amount,
          transactionRef: input.transactionRef,
          notes: input.notes,
        });

        // Update member's total contributed
        const member = await db.getMemberById(input.memberId);
        if (member) {
          const totalContributed = await db.getTotalContributionsByMember(input.memberId);
          const platformFee = calculatePlatformFee(parseFloat(totalContributed));
          const outstandingBalance = (parseFloat(totalContributed) - platformFee - parseFloat(member.totalDisbursed)).toString();

          await db.updateMemberBalance(
            input.memberId,
            totalContributed,
            member.totalDisbursed.toString(),
            platformFee.toFixed(2),
            outstandingBalance
          );
        }

        return { success: true };
      }),

    getByGroup: publicProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return await db.getContributionsByGroupId(input.groupId);
      }),

    getByMember: publicProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input }) => {
        return await db.getContributionsByMemberId(input.memberId);
      }),
  }),

  // ============ DISBURSEMENTS ============
  disbursements: router({
    create: protectedProcedure
      .input(z.object({
        memberId: z.number(),
        groupId: z.number(),
        amount: z.string().regex(/^\d+(\.\d{1,2})?$/),
        disbursementType: z.enum(["slot-based", "year-end"]),
        slotNumber: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createDisbursement({
          memberId: input.memberId,
          groupId: input.groupId,
          amount: input.amount,
          disbursementType: input.disbursementType,
          slotNumber: input.slotNumber,
        });

        return { success: true };
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        disbursementId: z.number(),
        status: z.enum(["pending", "processed", "completed", "failed"]),
      }))
      .mutation(async ({ input }) => {
        await db.updateDisbursementStatus(input.disbursementId, input.status);
        return { success: true };
      }),

    getByGroup: publicProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return await db.getDisbursementsByGroupId(input.groupId);
      }),

    getByMember: publicProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input }) => {
        return await db.getDisbursementsByMemberId(input.memberId);
      }),
  }),

  // ============ RECONCILIATION ============
  reconciliations: router({
    generate: protectedProcedure
      .input(z.object({
        memberId: z.number(),
        groupId: z.number(),
        reconciliationPeriod: z.string(),
      }))
      .mutation(async ({ input }) => {
        const member = await db.getMemberById(input.memberId);
        if (!member) throw new TRPCError({ code: "NOT_FOUND", message: "Member not found" });

        const totalContributed = parseFloat(member.totalContributed);
        const totalDisbursed = parseFloat(member.totalDisbursed);
        const platformFeeDeducted = calculatePlatformFee(totalContributed);
        const netBalance = totalContributed - platformFeeDeducted - totalDisbursed;

        await db.createReconciliation({
          memberId: input.memberId,
          groupId: input.groupId,
          reconciliationPeriod: input.reconciliationPeriod,
          totalContributions: member.totalContributed,
          totalDisbursements: member.totalDisbursed.toString(),
          platformFeeDeducted: platformFeeDeducted.toFixed(2),
          netBalance: netBalance.toFixed(2),
        });

        return { success: true };
      }),

    getByMember: publicProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input }) => {
        return await db.getReconciliationsByMemberId(input.memberId);
      }),

    getByGroup: publicProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return await db.getReconciliationsByGroupId(input.groupId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
