import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Download, Search, Filter } from "lucide-react";
import { toast } from "sonner";

export default function ContributionLedger() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");

  const [selectedGroupId, setSelectedGroupId] = useState<number | null>(1); // Default to group 1 for demo

  // Fetch contributions
  const { data: contributions, isLoading } = trpc.contributions.getByGroup.useQuery(
    { groupId: selectedGroupId || 0 },
    { enabled: !!selectedGroupId }
  );

  // Fetch groups - use a placeholder for now
  const groups = [];



  // Fetch member names for contributions
  const { data: allMembers } = trpc.members.getByGroup.useQuery(
    { groupId: selectedGroupId || 0 },
    { enabled: !!selectedGroupId }
  );

  // Create member name map
  const memberNameMap = new Map(
    allMembers?.map((m) => [m.id, m.memberName]) || []
  );

  // Filter contributions
  const filteredContributions = contributions?.filter((c) => {
    const memberName = memberNameMap.get(c.memberId) || `Member ${c.memberId}`;
    const matchesSearch =
      memberName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.id.toString().includes(searchTerm);
    return matchesSearch;
  }) || [];

  // Calculate statistics
  const totalContributions = filteredContributions.reduce(
    (sum, c) => sum + parseFloat(c.amount),
    0
  );
  const averageContribution =
    filteredContributions.length > 0 ? totalContributions / filteredContributions.length : 0;

  // Export to CSV
  const handleExport = () => {
    if (!filteredContributions.length) {
      toast.error("No contributions to export");
      return;
    }

    const headers = ["Date", "Member", "Amount (Ksh)", "Running Total"];
    let runningTotal = 0;
    const rows = filteredContributions.map((c: any) => {
      runningTotal += parseFloat(c.amount);
      return [
        new Date(c.contributionDate).toLocaleDateString(),
        memberNameMap.get(c.memberId) || `Member ${c.memberId}`,
        parseFloat(c.amount).toLocaleString(),
        runningTotal.toLocaleString(),
      ];
    });

    const csv = [
      headers.join(","),
      ...rows.map((row: any) => row.map((cell: any) => `"${cell}"`).join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `contribution-ledger-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success("Ledger exported successfully!");
  };

  if (!selectedGroupId) {
    return (
      <div className="min-h-screen bg-slate-950 p-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Contribution Ledger</h1>
          <Card className="border-slate-700 p-8 text-center">
            <p className="text-slate-400 mb-6">Select a group to view the contribution ledger</p>
            <div className="flex flex-wrap gap-3 justify-center">
              <p className="text-slate-400">No groups available. Create a group to get started.</p>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Contribution Ledger</h1>
          <p className="text-slate-400">
            Full transparency view of all group contributions
          </p>
        </div>

        {/* Statistics */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20 p-6">
            <p className="text-slate-400 text-sm mb-1">Total Contributions</p>
            <p className="text-2xl font-bold">Ksh {totalContributions.toLocaleString()}</p>
          </Card>

          <Card className="bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20 p-6">
            <p className="text-slate-400 text-sm mb-1">Number of Entries</p>
            <p className="text-2xl font-bold">{filteredContributions.length}</p>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20 p-6">
            <p className="text-slate-400 text-sm mb-1">Average Contribution</p>
            <p className="text-2xl font-bold">Ksh {averageContribution.toLocaleString()}</p>
          </Card>
        </div>

        {/* Controls */}
        <Card className="border-slate-700 mb-8 p-6">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex-1 flex gap-3 w-full md:w-auto">
              <div className="relative flex-1 md:flex-none md:w-64">
                <Search className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                <Input
                  placeholder="Search member or date..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-slate-900 border-slate-700 focus:border-blue-500"
                />
              </div>
              <Button variant="outline" className="gap-2 border-slate-700">
                <Filter className="w-4 h-4" />
                Filter
              </Button>
            </div>
            <Button
              onClick={handleExport}
              className="gap-2 bg-green-600 hover:bg-green-700 w-full md:w-auto"
            >
              <Download className="w-4 h-4" />
              Export CSV
            </Button>
          </div>
        </Card>

        {/* Contribution Table */}
        <Card className="border-slate-700 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-slate-700 bg-slate-900/50">
                <tr className="text-slate-400">
                  <th className="text-left p-4 font-semibold">Date</th>
                  <th className="text-left p-4 font-semibold">Member Name</th>
                  <th className="text-left p-4 font-semibold">Amount (Ksh)</th>
                  <th className="text-left p-4 font-semibold">Running Total</th>
                  <th className="text-left p-4 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={5} className="p-4 text-center text-slate-400">
                      Loading contributions...
                    </td>
                  </tr>
                ) : filteredContributions.length > 0 ? (
                  filteredContributions.map((contribution: any, index: number) => {
                    const runningTotal = filteredContributions
                      .slice(0, index + 1)
                      .reduce((sum, c) => sum + parseFloat(c.amount), 0);

                    return (
                      <tr
                        key={contribution.id}
                        className="border-b border-slate-700/50 hover:bg-slate-800/50"
                      >
                        <td className="p-4 text-slate-300">
                          {new Date(contribution.contributionDate).toLocaleDateString()}
                        </td>
                        <td className="p-4 font-semibold">
                          {memberNameMap.get(contribution.memberId) || `Member ${contribution.memberId}`}
                        </td>
                        <td className="p-4 text-green-400 font-semibold">
                          Ksh {parseFloat(contribution.amount).toLocaleString()}
                        </td>
                        <td className="p-4 text-blue-400 font-semibold">
                          Ksh {runningTotal.toLocaleString()}
                        </td>
                        <td className="p-4">
                          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-400">
                            Confirmed
                          </span>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={5} className="p-4 text-center text-slate-400">
                      No contributions recorded yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Transparency Notice */}
        <Card className="border-slate-700 mt-8 p-6 bg-blue-500/5">
          <h3 className="font-bold text-blue-400 mb-2">🔒 Full Transparency</h3>
          <p className="text-slate-300 text-sm">
            This ledger is visible to all group members. Every contribution is recorded with a
            timestamp and member identification. This ensures complete transparency and prevents
            disputes. The running total shows the cumulative group fund balance at each
            contribution point.
          </p>
        </Card>
      </div>
    </div>
  );
}
